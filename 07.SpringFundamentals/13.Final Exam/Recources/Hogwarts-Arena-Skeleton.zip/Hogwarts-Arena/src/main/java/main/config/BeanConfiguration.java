package main.config;

import org.springframework.context.annotation.Configuration;

@Configuration
public class BeanConfiguration {

    // TODO: Add necessary beans here.
}
