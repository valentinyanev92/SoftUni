package main.web;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/letters")
public class LettersController {

    //TODO: This class will be needed for Exercise 2 only.
}
