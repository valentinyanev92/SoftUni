package main.model;

public class Quest {

    // TODO:

}

