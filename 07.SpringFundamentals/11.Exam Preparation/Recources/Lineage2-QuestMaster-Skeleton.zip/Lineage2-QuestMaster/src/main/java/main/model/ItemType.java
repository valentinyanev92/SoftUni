package main.model;

public enum ItemType {

    // TODO:

}
