package main.model;

public enum PlayerRole {

    // TODO:

}
