package main.model;

public enum PlayerClass {

    // TODO:

}