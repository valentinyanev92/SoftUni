package main.model;

public enum BoosterType {

    // TODO: Complete enumeration

}
