package main.model;

public enum PlayerClass {

    // TODO: Complete enumeration

}
