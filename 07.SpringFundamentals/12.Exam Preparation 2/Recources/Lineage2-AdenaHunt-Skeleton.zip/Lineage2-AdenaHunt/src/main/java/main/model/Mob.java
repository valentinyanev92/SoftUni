package main.model;

public class Mob {

    // TODO: Complete entity

}

