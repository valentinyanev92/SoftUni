package main.model;

public enum MobType {

    // TODO: Complete enumeration

}
