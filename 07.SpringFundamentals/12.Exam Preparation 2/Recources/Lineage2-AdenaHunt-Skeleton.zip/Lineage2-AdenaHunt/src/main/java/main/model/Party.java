package main.model;

public class Party {

    // TODO: Complete entity

}
