package main.model;

public enum FightOutcome {

    // TODO: Complete enumeration

}
