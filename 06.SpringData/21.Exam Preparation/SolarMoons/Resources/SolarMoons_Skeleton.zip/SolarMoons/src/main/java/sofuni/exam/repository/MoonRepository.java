package sofuni.exam.repository;


//ToDo:
public interface MoonRepository  {


}
