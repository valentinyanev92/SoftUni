package softuni.exam.models.entity;

public enum CarType {
    COMBI, COUPE, HATCHBACK, SEDAN, SUV
}

