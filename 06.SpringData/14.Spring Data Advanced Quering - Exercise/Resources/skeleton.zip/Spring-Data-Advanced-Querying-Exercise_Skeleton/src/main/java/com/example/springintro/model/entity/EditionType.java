package com.example.springintro.model.entity;

public enum EditionType {
    NORMAL, PROMO, GOLD
}
